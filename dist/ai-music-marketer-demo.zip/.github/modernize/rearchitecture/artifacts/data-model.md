# Existing Data Model

The current ORM defines 13 SQLAlchemy tables in `backend/models.py`. All IDs are integer primary keys; relationships use foreign keys and ORM cascades as described.

| Entity / table | Fields | Relationships |
|---|---|---|
| `Song` / `songs` | `id`, `title`, `artist`, `genre`, `lyrics`, `bpm`, `musical_key`, `energy`, `valence`, `status`, `created_at`, `updated_at` | Has many runs, campaigns, and release-calendar entries. |
| `CampaignPlan` / `campaign_plans` | `id`, `song_id`, `name`, `objective`, `status`, `release_date`, `budget_total`, `channels`, `notes`, `created_at` | Belongs to song; has many tasks and calendar entries. |
| `CampaignTask` / `campaign_tasks` | `id`, `campaign_id`, `name`, `channel`, `owner`, `priority`, `due_in_days`, `status`, `description`, `created_at` | Belongs to campaign. |
| `ArtistProfile` / `artist_profiles` | `id`, `name`, `brand_voice`, `target_audience`, `goals`, `markets`, `created_at` | Standalone profile; endpoints select the most recently created row. |
| `ReleaseCalendarEntry` / `release_calendar_entries` | `id`, `song_id`, `campaign_id`, `title`, `entry_type`, `channel`, `scheduled_for`, `status`, `notes`, `created_at` | Optionally belongs to song and campaign; both foreign keys use `SET NULL`. |
| `Run` / `runs` | `id`, `song_id`, `status`, `error`, `logs`, `started_at`, `finished_at` | Belongs to song; one intelligence, one strategy, one metrics row, one optimization report, one final strategy, and many audience/content rows. |
| `SongIntelligenceRow` / `song_intelligence` | `id`, `run_id`, `bpm`, `musical_key`, `energy`, `valence`, `mood`, `structure`, `hooks`, `lyrical_themes`, `production_notes`, `a_r_insights` | One-to-one with run (`run_id` unique). |
| `AudienceSegmentRow` / `audience_segments` | `id`, `run_id`, `name`, `description`, `age_range`, `interests`, `platform_affinity`, `match_score`, `is_primary`, `rank` | Many-to-one with run. |
| `ContentPieceRow` / `content_pieces` | `id`, `run_id`, `format`, `hook`, `concept`, `caption`, `cta`, `sound_strategy`, `sort_index` | Many-to-one with run. |
| `MarketingStrategyRow` / `marketing_strategies` | `id`, `run_id`, `release_type`, `timeline_weeks`, `phases`, `platform_priority`, `budget_allocation`, `pitch_targets`, `key_message` | One-to-one with run (`run_id` unique). |
| `PerformanceMetricsRow` / `performance_metrics` | `id`, `run_id`, `streams`, `saves`, `playlist_adds`, `social_views`, `engagement_rate`, `follower_delta`, `score` | One-to-one with run (`run_id` unique). Values are simulated by the current analytics agent. |
| `OptimizationReportRow` / `optimization_reports` | `id`, `run_id`, `what_worked`, `what_underperformed`, `recommendations`, `lessons_learned` | One-to-one with run (`run_id` unique). |
| `FinalStrategyRow` / `final_strategies` | `id`, `run_id`, `orchestrator_summary`, `top_priority_actions` | One-to-one with run (`run_id` unique). |

JSON columns store list/dict structures for agent outputs and artist/campaign fields. `Song` owns cascading run/campaign/calendar collections; `Run` owns cascading output rows; `CampaignPlan` owns cascading task rows. The current startup path uses `Base.metadata.create_all`, with no Alembic migration history identified. The SQLite database has not been migrated or modified as part of architecture analysis.
