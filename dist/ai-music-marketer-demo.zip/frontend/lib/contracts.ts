export type Song = {
  song_id: string;
  title: string;
  artist_name: string | null;
  language: string | null;
  genre_preferences: string[];
  release_goal: string | null;
  created_at: string;
  updated_at: string;
};

export type Job = {
  job_id: string;
  task_type: string;
  status: string;
  stage: string;
  attempt: number;
  created_at: string;
  updated_at: string;
  started_at: string | null;
  finished_at: string | null;
  error: { code: string; message: string } | null;
};

export type FeatureValue = {
  value: number | string | Record<string, unknown> | null;
  status: "measured" | "derived" | "estimated" | "predicted" | "unavailable";
  unit: string | null;
  source: string;
  source_version: string | null;
  limitations: string[];
};

export type Intelligence = {
  analysis_id: string;
  song_id: string;
  schema_version: string;
  analysis_version: string;
  created_at: string;
  audio_features: Record<string, FeatureValue>;
  sections: Array<Record<string, unknown>>;
  hook_candidates: Array<Record<string, unknown>>;
  lyrics_analysis: Record<string, unknown>;
  predictions: Array<Record<string, unknown>>;
  limitations: string[];
  provenance: Array<Record<string, unknown>>;
};

export type EvidenceClaim = {
  claim: string;
  evidence_refs: string[];
  kind: "observed" | "measured" | "predicted" | "interpretation" | "recommendation";
};

export type ARReport = {
  report_id: string;
  analysis_id: string;
  schema_version: string;
  provider: string;
  model: string | null;
  prompt_version: string;
  created_at: string;
  summary: string;
  strengths: EvidenceClaim[];
  improvement_opportunities: EvidenceClaim[];
  hook_candidates: EvidenceClaim[];
  recommendations: EvidenceClaim[];
  limitations: string[];
  disclaimer: string;
};

export type Capabilities = {
  api_version: string;
  capabilities: {
    song_upload: boolean;
    audio_analysis: boolean;
    librosa_features: boolean;
    essentia_features: boolean;
    mock_ai_report: boolean;
    openrouter_report: boolean;
    social_publishing: boolean;
    music_distribution: boolean;
    paid_campaign_execution: boolean;
  };
};
