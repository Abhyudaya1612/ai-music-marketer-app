from __future__ import annotations

import math
import shutil
import struct
import uuid
import wave

import pytest

from backend.config import settings
from backend.services.audio import extract_features, verify_audio
from backend.services.storage import original_path


@pytest.mark.skipif(
    shutil.which(settings.ffprobe_path) is None or shutil.which(settings.ffmpeg_path) is None,
    reason="FFmpeg and FFprobe are required for this integration test.",
)
def test_audio_is_decoded_and_measured_without_changing_original(monkeypatch, tmp_path):
    monkeypatch.setattr(settings, "media_storage_path", str(tmp_path / "private"))
    storage_key = str(uuid.uuid4())
    source = original_path(storage_key)
    source.parent.mkdir(parents=True, exist_ok=True)
    sample_rate = 22050
    frames = (
        struct.pack("<h", int(12000 * math.sin(2 * math.pi * 440 * index / sample_rate)))
        for index in range(sample_rate)
    )
    with wave.open(str(source), "wb") as audio_file:
        audio_file.setnchannels(1)
        audio_file.setsampwidth(2)
        audio_file.setframerate(sample_rate)
        audio_file.writeframes(b"".join(frames))
    original_bytes = source.read_bytes()

    metadata = verify_audio(storage_key)
    result = extract_features(storage_key, "a" * 64)

    assert metadata["duration_seconds"] == pytest.approx(1.0, abs=0.02)
    assert metadata["sample_rate"] == sample_rate
    assert metadata["actual_content_type"] == "audio/wav"
    assert result["audio_features"]["duration_seconds"]["status"] == "measured"
    assert result["audio_features"]["duration_seconds"]["value"] == pytest.approx(1.0, abs=0.02)
    assert result["provenance"][0]["input_checksum_sha256"] == "a" * 64
    assert source.read_bytes() == original_bytes
    assert (source.parent / "analysis.wav").is_file()
