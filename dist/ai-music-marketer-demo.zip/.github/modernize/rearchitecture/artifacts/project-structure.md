# Project Structure and Rewrite Boundary

## Delivered target structure

- **Project type:** Local-first modular monolith with a Next.js App Router frontend and FastAPI API service.
- **Frontend:** `frontend/app/` contains the Next.js interface; `frontend/lib/` contains its API client and typed response contracts.
- **Backend:** Existing routes and ORM models remain available for legacy clients. The new `/api/v1` routes use `backend/domain/`, `backend/core/`, `backend/services/`, and durable SQLAlchemy job/analysis records.
- **First-slice worker:** `backend/services/job_runner.py` verifies uploaded audio and persists analysis/report outcomes; `backend/workers.py` remains the legacy agent pipeline.
- **Private media:** Original uploads and derived audio are stored outside the public frontend tree under `APP_MEDIA_STORAGE_PATH`.
- **Verification and packaging:** `tests/` covers legacy behavior, v1 API flow, and audio decoding; `scripts/package_demo.ps1` creates a source ZIP without local data or dependencies.
- **Runtime:** Run the Next.js frontend on port 3000 and FastAPI on port 8000. Docker Compose starts both services.
- **Data:** `music_marketer.db` remains the existing SQLite database; new `v1_*` tables are created without destructive migration.

## Preserved source behavior

- Legacy `/api/*` routes and their database models are retained; the existing heuristic agent pipeline remains behind those compatibility routes.
- Campaign, profile, calendar, and simulated analytics functionality are legacy behavior, not part of the new private audio-analysis milestone.
- The old static frontend has been replaced by the approved Next.js interface.

## Existing request flows

- Legacy song creation persists the legacy record and schedules the original pipeline through FastAPI `BackgroundTasks`.
- The worker creates a run, runs the deterministic five-agent pipeline, stores its output in related tables, and updates song/run status.
- The new v1 flow writes the private upload, validates it through FFprobe, creates a versioned analysis and durable job, then stores Song Intelligence and a schema-validated A&R report.
- Campaign, profile, calendar, and dashboard requests synchronously read/write the same SQLAlchemy database.

## Scope interpretation

The requested target is a new modular-monolith structure with Next.js frontend and FastAPI backend, while keeping the existing REST paths and response behavior available for legacy clients. The supplied specifications' initial acceptance boundary is the private audio upload → analysis job → versioned intelligence → A&R report flow. The existing campaign planner and simulated analytics are legacy behavior, not authorization to expand the new milestone.
