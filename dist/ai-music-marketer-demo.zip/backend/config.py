"""Application settings — all overridable via environment variables."""
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_prefix="APP_", extra="ignore")

    app_name: str = "AI Music Marketer"
    environment: str = "development"
    # SQLite by default; set APP_DATABASE_URL=postgresql+psycopg2://user:pass@host/db in prod
    database_url: str = "sqlite:///./music_marketer.db"
    cors_origins: str = "http://localhost:3000,http://localhost:8000"
    api_token: str = ""
    auth_user_id: str = "local-artist"
    media_storage_path: str = "./private-media"
    max_upload_bytes: int = 52_428_800
    max_audio_duration_seconds: int = 900
    ffmpeg_path: str = "ffmpeg"
    ffprobe_path: str = "ffprobe"
    ai_provider: str = "mock"
    openrouter_api_key: str = ""
    openrouter_model: str = ""
    openrouter_base_url: str = "https://openrouter.ai/api/v1"
    ai_provider_timeout_seconds: float = 20.0
    ai_provider_max_retries: int = 2

    @property
    def cors_origin_list(self) -> list[str]:
        return [o.strip() for o in self.cors_origins.split(",") if o.strip()]


settings = Settings()
