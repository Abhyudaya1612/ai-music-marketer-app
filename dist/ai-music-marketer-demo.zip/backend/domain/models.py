"""Persistence models for private assets, analysis jobs, intelligence, and reports."""
from __future__ import annotations

import uuid
from datetime import datetime, timedelta, timezone

from sqlalchemy import (
    Column,
    DateTime,
    Float,
    ForeignKey,
    Index,
    Integer,
    JSON,
    String,
    Text,
    UniqueConstraint,
)
from sqlalchemy.orm import relationship

from ..database import Base


def new_id() -> str:
    return str(uuid.uuid4())


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


class StudioSong(Base):
    __tablename__ = "v1_songs"

    id = Column(String(36), primary_key=True, default=new_id)
    owner_id = Column(String(120), nullable=False, index=True)
    title = Column(String(255), nullable=False)
    artist_name = Column(String(255), nullable=True)
    language = Column(String(32), nullable=True)
    genre_preferences = Column(JSON, nullable=False, default=list)
    release_goal = Column(Text, nullable=True)
    created_at = Column(DateTime(timezone=True), nullable=False, default=utcnow)
    updated_at = Column(DateTime(timezone=True), nullable=False, default=utcnow, onupdate=utcnow)
    assets = relationship("MediaAsset", back_populates="song", cascade="all, delete-orphan")
    analyses = relationship("SongAnalysis", back_populates="song", cascade="all, delete-orphan")


class MediaAsset(Base):
    __tablename__ = "v1_media_assets"

    id = Column(String(36), primary_key=True, default=new_id)
    song_id = Column(String(36), ForeignKey("v1_songs.id", ondelete="CASCADE"), nullable=False, index=True)
    owner_id = Column(String(120), nullable=False, index=True)
    asset_kind = Column(String(40), nullable=False, default="audio_original")
    filename = Column(String(255), nullable=False)
    declared_content_type = Column(String(120), nullable=True)
    status = Column(String(24), nullable=False, default="pending_upload", index=True)
    storage_key = Column(String(80), nullable=False, unique=True)
    expected_size_bytes = Column(Integer, nullable=False)
    size_bytes = Column(Integer, nullable=True)
    checksum_sha256 = Column(String(64), nullable=True)
    actual_content_type = Column(String(120), nullable=True)
    duration_seconds = Column(Float, nullable=True)
    created_at = Column(DateTime(timezone=True), nullable=False, default=utcnow)
    expires_at = Column(
        DateTime(timezone=True),
        nullable=False,
        default=lambda: utcnow() + timedelta(minutes=15),
    )
    song = relationship("StudioSong", back_populates="assets")


class AnalysisJob(Base):
    __tablename__ = "v1_jobs"

    id = Column(String(36), primary_key=True, default=new_id)
    owner_id = Column(String(120), nullable=False, index=True)
    task_type = Column(String(40), nullable=False)
    subject_id = Column(String(36), nullable=True, index=True)
    status = Column(String(24), nullable=False, default="queued", index=True)
    stage = Column(String(48), nullable=False, default="queued")
    attempt = Column(Integer, nullable=False, default=1)
    error_code = Column(String(80), nullable=True)
    created_at = Column(DateTime(timezone=True), nullable=False, default=utcnow)
    updated_at = Column(DateTime(timezone=True), nullable=False, default=utcnow, onupdate=utcnow)
    started_at = Column(DateTime(timezone=True), nullable=True)
    finished_at = Column(DateTime(timezone=True), nullable=True)
    analysis = relationship("SongAnalysis", back_populates="job", uselist=False)


class SongAnalysis(Base):
    __tablename__ = "v1_analyses"

    id = Column(String(36), primary_key=True, default=new_id)
    song_id = Column(String(36), ForeignKey("v1_songs.id", ondelete="CASCADE"), nullable=False, index=True)
    asset_id = Column(String(36), ForeignKey("v1_media_assets.id"), nullable=False)
    owner_id = Column(String(120), nullable=False, index=True)
    job_id = Column(String(36), ForeignKey("v1_jobs.id"), nullable=False, unique=True)
    status = Column(String(24), nullable=False, default="queued", index=True)
    stage = Column(String(48), nullable=False, default="queued")
    progress_percent = Column(Integer, nullable=True)
    schema_version = Column(String(20), nullable=False, default="1.0")
    analysis_version = Column(String(40), nullable=False, default="standard_v1")
    intelligence_json = Column(JSON, nullable=True)
    error_code = Column(String(80), nullable=True)
    created_at = Column(DateTime(timezone=True), nullable=False, default=utcnow)
    updated_at = Column(DateTime(timezone=True), nullable=False, default=utcnow, onupdate=utcnow)
    song = relationship("StudioSong", back_populates="analyses")
    asset = relationship("MediaAsset")
    job = relationship("AnalysisJob", back_populates="analysis")
    report = relationship("AnalysisReport", back_populates="analysis", uselist=False, cascade="all, delete-orphan")


class AnalysisReport(Base):
    __tablename__ = "v1_analysis_reports"

    id = Column(String(36), primary_key=True, default=new_id)
    analysis_id = Column(String(36), ForeignKey("v1_analyses.id", ondelete="CASCADE"), nullable=False, unique=True, index=True)
    provider = Column(String(40), nullable=False)
    model = Column(String(160), nullable=True)
    prompt_version = Column(String(40), nullable=False)
    payload = Column(JSON, nullable=False)
    created_at = Column(DateTime(timezone=True), nullable=False, default=utcnow)
    analysis = relationship("SongAnalysis", back_populates="report")


class IdempotencyRecord(Base):
    __tablename__ = "v1_idempotency_records"
    __table_args__ = (
        UniqueConstraint("owner_id", "operation", "key", name="uq_v1_idempotency_scope"),
    )

    id = Column(Integer, primary_key=True)
    owner_id = Column(String(120), nullable=False)
    operation = Column(String(120), nullable=False)
    key = Column(String(200), nullable=False)
    request_hash = Column(String(64), nullable=False)
    response_json = Column(JSON, nullable=False)
    created_at = Column(DateTime(timezone=True), nullable=False, default=utcnow)


Index("ix_v1_analysis_song_created", SongAnalysis.song_id, SongAnalysis.created_at)
