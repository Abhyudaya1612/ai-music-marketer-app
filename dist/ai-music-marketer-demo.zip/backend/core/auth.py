"""Single-workspace bearer authentication for the local presentation build."""
from __future__ import annotations

import hmac

from fastapi import Depends
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer

from ..config import settings
from .errors import ApiError

_bearer = HTTPBearer(auto_error=False)


def current_owner(
    credentials: HTTPAuthorizationCredentials | None = Depends(_bearer),
) -> str:
    if not settings.api_token:
        raise ApiError(
            503,
            "AUTH_CONFIGURATION_MISSING",
            "Private API access is not configured. Set APP_API_TOKEN and restart the app.",
        )
    if credentials is None or not hmac.compare_digest(
        credentials.credentials, settings.api_token
    ):
        raise ApiError(401, "AUTHENTICATION_REQUIRED", "A valid bearer token is required.")
    return settings.auth_user_id
