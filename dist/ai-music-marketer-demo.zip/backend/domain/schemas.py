"""Versioned request and response contracts for the first product slice."""
from __future__ import annotations

from datetime import datetime
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field


class SongCreate(BaseModel):
    title: str = Field(min_length=1, max_length=255)
    artist_name: str | None = Field(default=None, max_length=255)
    language: str | None = Field(default=None, max_length=32)
    genre_preferences: list[str] = Field(default_factory=list, max_length=20)
    release_goal: str | None = Field(default=None, max_length=2000)


class SongPatch(BaseModel):
    title: str | None = Field(default=None, min_length=1, max_length=255)
    artist_name: str | None = Field(default=None, max_length=255)
    language: str | None = Field(default=None, max_length=32)
    genre_preferences: list[str] | None = Field(default=None, max_length=20)
    release_goal: str | None = Field(default=None, max_length=2000)


class SongOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    song_id: str
    title: str
    artist_name: str | None
    language: str | None
    genre_preferences: list[str]
    release_goal: str | None
    created_at: datetime
    updated_at: datetime


class UploadIntentRequest(BaseModel):
    filename: str = Field(min_length=1, max_length=255)
    declared_content_type: str | None = Field(default=None, max_length=120)
    size_bytes: int = Field(gt=0)
    asset_kind: Literal["audio_original"] = "audio_original"


class UploadIntentResponse(BaseModel):
    asset_id: str
    upload_method: Literal["PUT"]
    upload_url: str
    required_headers: dict[str, str]
    expires_at: datetime


class AssetCompleteRequest(BaseModel):
    asset_id: str


class AssetOut(BaseModel):
    asset_id: str
    asset_kind: str
    status: str
    size_bytes: int | None
    checksum_sha256: str | None
    created_at: datetime


class AssetListOut(BaseModel):
    items: list[AssetOut]
    next_cursor: str | None = None


class AssetCompleteResponse(BaseModel):
    asset_id: str
    status: str
    job_id: str
    status_url: str


class AnalysisRequest(BaseModel):
    asset_id: str
    lyrics_asset_id: str | None = None
    analysis_profile: Literal["standard_v1"] = "standard_v1"
    include_pretrained_predictions: bool = False
    generate_ai_report: bool = True


class AnalysisAccepted(BaseModel):
    analysis_id: str
    job_id: str
    status: str
    status_url: str
    requested_at: datetime


class SafeError(BaseModel):
    code: str
    message: str


class AnalysisStatusOut(BaseModel):
    analysis_id: str
    song_id: str
    status: str
    stage: str
    progress_percent: int | None
    created_at: datetime
    updated_at: datetime
    error: SafeError | None


class JobOut(BaseModel):
    job_id: str
    task_type: str
    status: str
    stage: str
    attempt: int
    created_at: datetime
    updated_at: datetime
    started_at: datetime | None
    finished_at: datetime | None
    error: SafeError | None


class FeatureValue(BaseModel):
    value: float | int | str | dict[str, Any] | None
    status: Literal["measured", "derived", "estimated", "predicted", "unavailable"]
    unit: str | None = None
    source: str
    source_version: str | None = None
    limitations: list[str] = Field(default_factory=list)


class HookCandidate(BaseModel):
    start_seconds: float | None = None
    end_seconds: float | None = None
    kind: Literal["lyrical", "melodic", "rhythmic", "instrumental", "unknown"]
    text: str | None = None
    evidence: str


class SongIntelligenceOut(BaseModel):
    analysis_id: str
    song_id: str
    schema_version: str
    analysis_version: str
    created_at: datetime
    audio_features: dict[str, FeatureValue]
    sections: list[dict[str, Any]]
    hook_candidates: list[HookCandidate]
    lyrics_analysis: dict[str, Any]
    predictions: list[dict[str, Any]]
    limitations: list[str]
    provenance: list[dict[str, Any]]


class EvidenceClaim(BaseModel):
    claim: str = Field(min_length=1, max_length=1000)
    evidence_refs: list[str] = Field(default_factory=list)
    kind: Literal["observed", "measured", "predicted", "interpretation", "recommendation"]


class ARReportPayload(BaseModel):
    model_config = ConfigDict(extra="forbid")

    summary: str = Field(min_length=1, max_length=2000)
    strengths: list[EvidenceClaim] = Field(default_factory=list)
    improvement_opportunities: list[EvidenceClaim] = Field(default_factory=list)
    hook_candidates: list[EvidenceClaim] = Field(default_factory=list)
    recommendations: list[EvidenceClaim] = Field(default_factory=list)
    limitations: list[str] = Field(default_factory=list)
    disclaimer: str = "Decision support only; this report does not guarantee commercial success."


class ARReportOut(ARReportPayload):
    report_id: str
    analysis_id: str
    schema_version: str
    provider: str
    model: str | None
    prompt_version: str
    created_at: datetime


class ErrorDetails(BaseModel):
    code: str
    message: str
    request_id: str
    details: list[dict[str, Any]] = Field(default_factory=list)


class ErrorEnvelope(BaseModel):
    error: ErrorDetails
