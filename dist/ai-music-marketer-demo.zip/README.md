# AI Music Marketer

A private-first prototype for independent artists. The first working slice takes a local audio file through upload, media validation, versioned Song Intelligence, and an evidence-limited A&R report.

The larger product specification describes future release planning and marketing capabilities. Those features are not represented as live integrations here: the current app does not publish music, connect social accounts, run ads, or promise commercial results.

## Project layout

```text
backend/
  core/                 # local bearer auth and safe API errors
  domain/               # v1 SQLAlchemy models and Pydantic contracts
  routers/              # preserved legacy endpoints and /api/v1
  services/             # private storage, audio processing, report providers
  workers.py            # preserved legacy pipeline
  services/job_runner.py# first-slice asynchronous job processing
frontend/
  app/                  # Next.js App Router UI
  lib/                  # v1 API client and shared contracts
tests/                  # legacy and v1 API integration tests
scripts/package_demo.ps1
```

The old `/api/*` endpoints and tables remain in place. The new feature uses separate `v1_*` SQLite tables; startup creates missing tables without replacing the existing database. No destructive data migration is performed.

## Local setup

Requirements: Python 3.11+ (tested with Python 3.14), Node.js 22+, npm, and FFmpeg/FFprobe available on `PATH`.

1. Create local settings and a private workspace token:

   ```powershell
   Copy-Item .env.example .env
   $token = [Convert]::ToHexString([Security.Cryptography.RandomNumberGenerator]::GetBytes(32))
   (Get-Content .env) -replace '^APP_API_TOKEN=.*$', "APP_API_TOKEN=$token" | Set-Content .env
   ```

   Keep `.env` private. The UI asks for this token and keeps it in the current browser session only.

2. Install Python and frontend dependencies:

   ```powershell
   .\.venv\Scripts\python.exe -m pip install -r requirements.txt
   Set-Location frontend
   npm ci
   Set-Location ..
   ```

   On first use, create the Python environment with `py -m venv .venv`.

3. Start the API and web app in separate PowerShell windows:

   ```powershell
   .\.venv\Scripts\python.exe -m uvicorn backend.main:app --host 0.0.0.0 --port 8000
   ```

   ```powershell
   Set-Location frontend
   npm run dev
   ```

   Open `http://localhost:3000`. API documentation is at `http://localhost:8000/docs`.

### Sharing on a local network

Both development servers bind to `0.0.0.0`. To open the app from another device, use the host computer's LAN address, for example `http://192.168.1.20:3000`. Add that exact origin to `APP_CORS_ORIGINS` in `.env` (for example `http://localhost:3000,http://192.168.1.20:3000`) and restart the API. Allow inbound TCP ports 3000 and 8000 in the host firewall only on a trusted private network. The API token is a shared local-workspace credential, not multi-user authentication; do not expose this prototype to the public internet.

The browser derives the API host from the hostname used to open the web app, so both services should use the same host name/IP. For HTTPS reverse-proxy use, set `NEXT_PUBLIC_API_BASE_URL` at frontend build time to the HTTPS API origin.

## Audio and report behavior

- Original audio is stored under `APP_MEDIA_STORAGE_PATH` outside the public frontend directory. Uploads are bounded by size and duration, checksummed, and validated by decoding through FFprobe; FFmpeg creates a derived mono WAV for analysis.
- FFprobe/FFmpeg file facts are measured. Librosa tempo/RMS and Essentia key are optional and explicitly labeled estimated when available. Missing tools or unsupported measurements are surfaced as unavailable; they are never fabricated.
- `APP_AI_PROVIDER=mock` is the offline default. It emits a small, deterministic report and does not call an external service.
- To use OpenRouter, set `APP_AI_PROVIDER=openrouter`, `APP_OPENROUTER_API_KEY`, and `APP_OPENROUTER_MODEL` in the backend environment. Only the song title and derived structured analysis are sent for report generation; the original audio is not sent. The response is schema-validated, evidence references are checked, and provider failures are recorded as job errors. Never put the provider key in a `NEXT_PUBLIC_*` variable.
- Lyrics analysis, hook/section detection, audience predictions, and real platform metrics are not enabled in this first slice. Capabilities and report limitations state this explicitly.

## Data and privacy

The default database is `music_marketer.db`; the first-slice media directory defaults to `private-media/`. Both are local and excluded from the presentation ZIP. Back up or securely delete these directories yourself when handling real unreleased music. This prototype has one configured `APP_AUTH_USER_ID` and one bearer token; it is not a multi-tenant identity system or a production security boundary.

## Verification

```powershell
.\.venv\Scripts\python.exe -m pytest tests -q
Set-Location frontend
npm run typecheck
npm run lint
npm run build
```

## Create a shareable source ZIP

Run from the project root:

```powershell
.\scripts\package_demo.ps1
```

The archive is written to `dist/ai-music-marketer-demo.zip`. It excludes dependency folders, build outputs, local `.env` files, databases, and private media. The recipient installs dependencies and configures a fresh local token following this README.

## Docker Compose

Copy `.env.example` to `.env`, set a strong `APP_API_TOKEN`, then run `docker compose up --build`. The frontend is on port 3000 and the API on port 8000. Update `APP_CORS_ORIGINS` in `.env` with the exact LAN frontend origin before using it from another device. SQLite and private audio live in the persistent `app-data` volume.
