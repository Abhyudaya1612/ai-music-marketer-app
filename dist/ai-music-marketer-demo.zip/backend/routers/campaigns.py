"""Campaign and release-planning endpoints."""
from __future__ import annotations

from datetime import datetime
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session, selectinload

from .. import models, schemas
from ..database import get_db

router = APIRouter(prefix="/api/campaigns", tags=["campaigns"])


@router.get("", response_model=list[schemas.CampaignPlanOut])
def list_campaigns(db: Session = Depends(get_db)):
    return (
        db.query(models.CampaignPlan)
        .options(selectinload(models.CampaignPlan.tasks))
        .order_by(models.CampaignPlan.release_date.asc())
        .all()
    )


@router.get("/{campaign_id}", response_model=schemas.CampaignPlanOut)
def get_campaign(campaign_id: int, db: Session = Depends(get_db)):
    campaign = (
        db.query(models.CampaignPlan)
        .options(selectinload(models.CampaignPlan.tasks))
        .filter(models.CampaignPlan.id == campaign_id)
        .first()
    )
    if not campaign:
        raise HTTPException(404, "Campaign not found")
    return campaign


@router.post("", response_model=schemas.CampaignPlanOut, status_code=201)
def create_campaign(payload: schemas.CampaignPlanCreate, db: Session = Depends(get_db)):
    song = db.get(models.Song, payload.song_id) if hasattr(payload, "song_id") else None
    if song is None and hasattr(payload, "song_id"):
        raise HTTPException(404, "Song not found")

    if not hasattr(payload, "song_id"):
        raise HTTPException(400, "song_id is required")

    plan = models.CampaignPlan(
        song_id=payload.song_id,
        name=payload.name,
        objective=payload.objective,
        status=payload.status,
        release_date=payload.release_date or datetime.utcnow(),
        budget_total=payload.budget_total,
        channels=payload.channels,
        notes=payload.notes,
    )
    db.add(plan)
    db.flush()

    for task in payload.tasks:
        db.add(
            models.CampaignTask(
                campaign_id=plan.id,
                name=task.name,
                channel=task.channel,
                owner=task.owner,
                priority=task.priority,
                due_in_days=task.due_in_days,
                status=task.status,
                description=task.description,
            )
        )

    db.commit()
    db.refresh(plan)
    return plan


@router.patch("/{campaign_id}/tasks/{task_id}", response_model=schemas.CampaignTaskOut)
def update_task_status(campaign_id: int, task_id: int, payload: dict, db: Session = Depends(get_db)):
    task = (
        db.query(models.CampaignTask)
        .filter(models.CampaignTask.id == task_id, models.CampaignTask.campaign_id == campaign_id)
        .first()
    )
    if not task:
        raise HTTPException(404, "Campaign task not found")

    if "status" in payload:
        task.status = payload["status"]
    if "priority" in payload:
        task.priority = payload["priority"]
    if "owner" in payload:
        task.owner = payload["owner"]

    db.commit()
    db.refresh(task)
    return task


@router.delete("/{campaign_id}", status_code=204)
def delete_campaign(campaign_id: int, db: Session = Depends(get_db)):
    campaign = db.get(models.CampaignPlan, campaign_id)
    if not campaign:
        raise HTTPException(404, "Campaign not found")
    db.delete(campaign)
    db.commit()
