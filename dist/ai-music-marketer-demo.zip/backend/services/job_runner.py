"""Persistent in-process worker for the local first-slice jobs."""
from __future__ import annotations

import logging
from datetime import datetime, timezone

from sqlalchemy.orm import Session

from ..core.errors import ApiError
from ..database import SessionLocal
from ..domain.models import AnalysisJob, AnalysisReport, MediaAsset, SongAnalysis, StudioSong
from .ai_provider import PROMPT_VERSION, get_report_provider
from .audio import extract_features, verify_audio

logger = logging.getLogger(__name__)


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


def _fail_job(db: Session, job: AnalysisJob, error_code: str, analysis: SongAnalysis | None = None) -> None:
    now = _utcnow()
    job.status = "failed"
    job.stage = "failed"
    job.error_code = error_code
    job.finished_at = now
    job.updated_at = now
    if analysis is not None:
        analysis.status = "failed"
        analysis.stage = "failed"
        analysis.error_code = error_code
        analysis.progress_percent = 100
        analysis.updated_at = now


def run_v1_job(job_id: str, generate_ai_report: bool = True) -> None:
    """Run one durable job and record every terminal outcome in the database."""
    db = SessionLocal()
    try:
        job = db.query(AnalysisJob).filter(AnalysisJob.id == job_id).first()
        if job is None or job.status != "queued":
            return
        job.status = "running"
        job.stage = "starting"
        job.started_at = _utcnow()
        job.updated_at = job.started_at
        db.commit()
        if job.task_type == "asset_verification":
            _verify_asset_job(db, job)
        elif job.task_type == "song_analysis":
            _analysis_job(db, job, generate_ai_report)
        else:
            _fail_job(db, job, "INTERNAL_ERROR")
            db.commit()
    except Exception as exc:
        logger.error("First-slice job failed job_id=%s exception_type=%s", job_id, type(exc).__name__)
        try:
            db.rollback()
            job = db.query(AnalysisJob).filter(AnalysisJob.id == job_id).first()
            if job is not None and job.status not in {"succeeded", "failed"}:
                analysis = (
                    db.query(SongAnalysis).filter(SongAnalysis.id == job.subject_id).first()
                    if job.task_type == "song_analysis"
                    else None
                )
                _fail_job(db, job, "INTERNAL_ERROR", analysis)
                db.commit()
        except Exception as persist_exc:
            logger.error(
                "Unable to persist job failure job_id=%s exception_type=%s",
                job_id,
                type(persist_exc).__name__,
            )
            db.rollback()
    finally:
        db.close()


def _verify_asset_job(db: Session, job: AnalysisJob) -> None:
    asset = db.query(MediaAsset).filter(
        MediaAsset.id == job.subject_id,
        MediaAsset.owner_id == job.owner_id,
    ).first()
    if asset is None:
        _fail_job(db, job, "RESOURCE_NOT_FOUND")
        db.commit()
        return
    try:
        metadata = verify_audio(asset.storage_key)
        asset.duration_seconds = metadata["duration_seconds"]
        asset.actual_content_type = metadata["actual_content_type"]
        asset.status = "ready"
        job.status = "succeeded"
        job.stage = "completed"
        job.finished_at = _utcnow()
        job.updated_at = job.finished_at
        db.commit()
    except ApiError as exc:
        asset.status = "failed"
        _fail_job(db, job, exc.code)
        db.commit()


def _analysis_job(db: Session, job: AnalysisJob, generate_ai_report: bool) -> None:
    analysis = db.query(SongAnalysis).filter(
        SongAnalysis.id == job.subject_id,
        SongAnalysis.owner_id == job.owner_id,
    ).first()
    if analysis is None:
        _fail_job(db, job, "RESOURCE_NOT_FOUND")
        db.commit()
        return
    analysis.status = "running"
    analysis.stage = "audio_processing"
    analysis.progress_percent = 10
    analysis.updated_at = _utcnow()
    job.stage = analysis.stage
    job.updated_at = analysis.updated_at
    db.commit()
    asset = db.query(MediaAsset).filter(
        MediaAsset.id == analysis.asset_id,
        MediaAsset.owner_id == job.owner_id,
        MediaAsset.status == "ready",
    ).first()
    song = db.query(StudioSong).filter(
        StudioSong.id == analysis.song_id,
        StudioSong.owner_id == job.owner_id,
    ).first()
    if asset is None or song is None:
        _fail_job(db, job, "RESOURCE_NOT_FOUND", analysis)
        db.commit()
        return
    try:
        intelligence = extract_features(asset.storage_key, asset.checksum_sha256 or "")
        analysis.stage = "validating_features"
        analysis.progress_percent = 75
        analysis.updated_at = _utcnow()
        job.stage = analysis.stage
        job.updated_at = analysis.updated_at
        db.commit()

        provider_name = "none"
        provider_model = None
        if generate_ai_report:
            analysis.stage = "generating_report"
            analysis.progress_percent = 85
            analysis.updated_at = _utcnow()
            job.stage = analysis.stage
            job.updated_at = analysis.updated_at
            db.commit()
            provider = get_report_provider()
            report_payload = provider.generate(song.title, intelligence)
            provider_name = provider.name
            provider_model = provider.model
        else:
            report_payload = None

        analysis.intelligence_json = intelligence
        analysis.status = "succeeded"
        analysis.stage = "completed"
        analysis.progress_percent = 100
        analysis.updated_at = _utcnow()
        job.status = "succeeded"
        job.stage = "completed"
        job.finished_at = analysis.updated_at
        job.updated_at = analysis.updated_at
        if report_payload is not None:
            db.add(
                AnalysisReport(
                    analysis_id=analysis.id,
                    provider=provider_name,
                    model=provider_model,
                    prompt_version=PROMPT_VERSION,
                    payload=report_payload.model_dump(mode="json"),
                )
            )
        db.commit()
    except ApiError as exc:
        _fail_job(db, job, exc.code, analysis)
        db.commit()
    except Exception:
        raise
