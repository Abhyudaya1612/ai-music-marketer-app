from __future__ import annotations

import os
import sys
import tempfile

os.environ.setdefault("APP_DATABASE_URL", f"sqlite:///{tempfile.mktemp(suffix='_v1.db')}")
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from fastapi.testclient import TestClient  # noqa: E402

from backend.config import settings  # noqa: E402
from backend.main import app  # noqa: E402

client = TestClient(app)
AUTH = {"Authorization": "Bearer test-studio-token"}


def test_v1_upload_analysis_and_report_flow(monkeypatch, tmp_path):
    monkeypatch.setattr(settings, "api_token", "test-studio-token")
    monkeypatch.setattr(settings, "auth_user_id", "test-artist")
    monkeypatch.setattr(settings, "media_storage_path", str(tmp_path / "media"))

    from backend.services import job_runner

    monkeypatch.setattr(
        job_runner,
        "verify_audio",
        lambda _key: {
            "duration_seconds": 42.5,
            "sample_rate": 44100,
            "channels": 2,
            "actual_content_type": "audio/wav",
        },
    )
    monkeypatch.setattr(
        job_runner,
        "extract_features",
        lambda _key, checksum: {
            "audio_features": {
                "duration_seconds": {
                    "value": 42.5,
                    "status": "measured",
                    "unit": "seconds",
                    "source": "ffprobe",
                    "source_version": "test",
                    "limitations": [],
                },
                "tempo_bpm": {
                    "value": 120.0,
                    "status": "estimated",
                    "unit": "bpm",
                    "source": "librosa",
                    "source_version": "test",
                    "limitations": [],
                },
            },
            "sections": [],
            "hook_candidates": [],
            "lyrics_analysis": {"available": False, "themes": [], "candidate_lines": []},
            "predictions": [],
            "limitations": ["No listening or audience response data was available."],
            "provenance": [{"component": "test", "version": "1", "input_checksum_sha256": checksum}],
        },
    )

    created = client.post("/api/v1/songs", headers=AUTH, json={"title": "Small Hours"})
    assert created.status_code == 201, created.text
    song_id = created.json()["song_id"]

    intent = client.post(
        f"/api/v1/songs/{song_id}/assets/upload-intent",
        headers=AUTH,
        json={
            "filename": "..\\demo.wav",
            "declared_content_type": "audio/wav",
            "size_bytes": 12,
            "asset_kind": "audio_original",
        },
    )
    assert intent.status_code == 201, intent.text
    assert "demo.wav" not in intent.json()["upload_url"]
    asset_id = intent.json()["asset_id"]

    uploaded = client.put(
        f"/api/v1/assets/{asset_id}/upload",
        headers=AUTH,
        content=b"not-a-real-wav",
    )
    assert uploaded.status_code == 400
    assert uploaded.json()["error"]["code"] == "UPLOAD_SIZE_MISMATCH"

    uploaded = client.put(
        f"/api/v1/assets/{asset_id}/upload",
        headers=AUTH,
        content=b"123456789012",
    )
    assert uploaded.status_code == 204
    completed = client.post(
        f"/api/v1/songs/{song_id}/assets/complete",
        headers=AUTH,
        json={"asset_id": asset_id},
    )
    assert completed.status_code == 202, completed.text
    assert client.get(completed.json()["status_url"], headers=AUTH).json()["status"] == "succeeded"

    analysis_request = {
        "asset_id": asset_id,
        "analysis_profile": "standard_v1",
        "include_pretrained_predictions": False,
        "generate_ai_report": True,
    }
    accepted = client.post(
        f"/api/v1/songs/{song_id}/analyses",
        headers={**AUTH, "Idempotency-Key": "analysis-test-key"},
        json=analysis_request,
    )
    assert accepted.status_code == 202, accepted.text
    analysis_id = accepted.json()["analysis_id"]
    assert client.get(accepted.json()["status_url"], headers=AUTH).json()["status"] == "succeeded"

    replay = client.post(
        f"/api/v1/songs/{song_id}/analyses",
        headers={**AUTH, "Idempotency-Key": "analysis-test-key"},
        json=analysis_request,
    )
    assert replay.status_code == 202
    assert replay.json()["analysis_id"] == analysis_id
    changed = client.post(
        f"/api/v1/songs/{song_id}/analyses",
        headers={**AUTH, "Idempotency-Key": "analysis-test-key"},
        json={**analysis_request, "generate_ai_report": False},
    )
    assert changed.status_code == 409
    assert changed.json()["error"]["code"] == "IDEMPOTENCY_CONFLICT"

    intelligence = client.get(f"/api/v1/analyses/{analysis_id}/intelligence", headers=AUTH)
    assert intelligence.status_code == 200
    assert intelligence.json()["audio_features"]["duration_seconds"]["status"] == "measured"
    report = client.get(f"/api/v1/analyses/{analysis_id}/report", headers=AUTH)
    assert report.status_code == 200
    assert report.json()["provider"] == "mock"
    assert all(
        reference in {
            f"audio_features.{key}" for key, value in intelligence.json()["audio_features"].items()
            if value["value"] is not None
        }
        for section in ("strengths", "improvement_opportunities", "hook_candidates", "recommendations")
        for claim in report.json()[section]
        for reference in claim["evidence_refs"]
    )


def test_v1_private_routes_require_bearer_token(monkeypatch):
    monkeypatch.setattr(settings, "api_token", "configured-test-token")
    response = client.post("/api/v1/songs", json={"title": "Private"})
    assert response.status_code == 401
    assert response.json()["error"]["code"] == "AUTHENTICATION_REQUIRED"
    assert response.headers.get("X-Request-ID")


def test_v1_api_error_envelope_on_validation(monkeypatch):
    monkeypatch.setattr(settings, "api_token", "test-studio-token")
    response = client.post("/api/v1/songs", headers=AUTH, json={"title": ""})
    assert response.status_code == 422
    assert response.json()["error"]["code"] == "VALIDATION_ERROR"
    assert response.json()["error"]["request_id"]
