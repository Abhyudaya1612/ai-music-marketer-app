"""Versioned first-slice API: private songs, uploads, analysis, and reports."""
from __future__ import annotations

import hashlib
import json
import shutil
from datetime import datetime, timezone
from pathlib import PurePosixPath

from fastapi import APIRouter, BackgroundTasks, Depends, Header, Request, Response, status
from sqlalchemy.orm import Session

from ..config import settings
from ..core.auth import current_owner
from ..core.errors import ApiError
from ..database import Base, get_db
from ..domain.models import (
    AnalysisJob,
    AnalysisReport,
    IdempotencyRecord,
    MediaAsset,
    SongAnalysis,
    StudioSong,
    new_id,
)
from ..domain.schemas import (
    ARReportOut,
    AnalysisAccepted,
    AnalysisRequest,
    AnalysisStatusOut,
    AssetCompleteRequest,
    AssetCompleteResponse,
    AssetListOut,
    AssetOut,
    JobOut,
    SafeError,
    SongCreate,
    SongIntelligenceOut,
    SongOut,
    SongPatch,
    UploadIntentRequest,
    UploadIntentResponse,
)
from ..services.storage import asset_directory, original_path, write_upload
from ..services.job_runner import run_v1_job

router = APIRouter(prefix="/api/v1", tags=["v1"])


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


def _utc(value: datetime | None) -> datetime | None:
    if value is None or value.tzinfo is not None:
        return value
    return value.replace(tzinfo=timezone.utc)


def _song_response(song: StudioSong) -> SongOut:
    return SongOut(
        song_id=song.id,
        title=song.title,
        artist_name=song.artist_name,
        language=song.language,
        genre_preferences=song.genre_preferences or [],
        release_goal=song.release_goal,
        created_at=_utc(song.created_at),
        updated_at=_utc(song.updated_at),
    )


def _get_song(db: Session, song_id: str, owner_id: str) -> StudioSong:
    song = db.query(StudioSong).filter(
        StudioSong.id == song_id,
        StudioSong.owner_id == owner_id,
    ).first()
    if song is None:
        raise ApiError(404, "RESOURCE_NOT_FOUND", "Song was not found.")
    return song


def _get_analysis(db: Session, analysis_id: str, owner_id: str) -> SongAnalysis:
    analysis = db.query(SongAnalysis).filter(
        SongAnalysis.id == analysis_id,
        SongAnalysis.owner_id == owner_id,
    ).first()
    if analysis is None:
        raise ApiError(404, "RESOURCE_NOT_FOUND", "Analysis was not found.")
    return analysis


def _error(code: str | None, message: str | None) -> SafeError | None:
    if code is None:
        return None
    safe_messages = {
        "AUDIO_FILE_TOO_LARGE": "The audio file exceeds the configured size limit.",
        "AUDIO_DURATION_EXCEEDED": "The audio file exceeds the configured duration limit.",
        "AUDIO_FORMAT_UNSUPPORTED": "The uploaded audio format is not supported.",
        "AUDIO_FILE_CORRUPT": "The uploaded audio could not be decoded.",
        "AUDIO_ANALYZER_UNAVAILABLE": "The configured audio processing tools are unavailable.",
        "AUDIO_PROCESSING_FAILED": "Audio processing failed.",
        "AI_PROVIDER_UNAVAILABLE": "The report provider is unavailable.",
        "AI_OUTPUT_INVALID": "The report provider returned a response that failed validation.",
        "INTERNAL_ERROR": "The requested job failed unexpectedly.",
        "WORKER_INTERRUPTED": "The job was interrupted before completion.",
    }
    return SafeError(code=code, message=safe_messages.get(code, "The requested operation failed."))


@router.get("/health")
def health() -> dict[str, str]:
    return {"status": "ok"}


@router.get("/ready")
def ready(db: Session = Depends(get_db)) -> dict[str, str]:
    try:
        db.execute(Base.metadata.tables["v1_songs"].select().limit(0))
    except Exception as exc:
        raise ApiError(503, "DEPENDENCY_UNAVAILABLE", "The application is not ready.") from exc
    return {"status": "ready"}


@router.get("/capabilities")
def capabilities() -> dict:
    import importlib.util

    ffmpeg_available = shutil.which(settings.ffmpeg_path) is not None
    ffprobe_available = shutil.which(settings.ffprobe_path) is not None
    openrouter_available = bool(settings.openrouter_api_key and settings.openrouter_model)
    return {
        "api_version": "v1",
        "capabilities": {
            "song_upload": True,
            "audio_analysis": ffmpeg_available and ffprobe_available,
            "librosa_features": importlib.util.find_spec("librosa") is not None,
            "essentia_features": importlib.util.find_spec("essentia") is not None,
            "mock_ai_report": True,
            "openrouter_report": openrouter_available,
            "social_publishing": False,
            "music_distribution": False,
            "paid_campaign_execution": False,
        },
    }


@router.get("/session")
def session_check(owner_id: str = Depends(current_owner)) -> dict[str, bool]:
    return {"authenticated": bool(owner_id)}


@router.post("/songs", response_model=SongOut, status_code=status.HTTP_201_CREATED)
def create_song(
    payload: SongCreate,
    db: Session = Depends(get_db),
    owner_id: str = Depends(current_owner),
) -> SongOut:
    song = StudioSong(owner_id=owner_id, **payload.model_dump())
    db.add(song)
    db.commit()
    db.refresh(song)
    return _song_response(song)


@router.get("/songs/{song_id}", response_model=SongOut)
def get_song(
    song_id: str,
    db: Session = Depends(get_db),
    owner_id: str = Depends(current_owner),
) -> SongOut:
    return _song_response(_get_song(db, song_id, owner_id))


@router.patch("/songs/{song_id}", response_model=SongOut)
def patch_song(
    song_id: str,
    payload: SongPatch,
    db: Session = Depends(get_db),
    owner_id: str = Depends(current_owner),
) -> SongOut:
    song = _get_song(db, song_id, owner_id)
    changes = payload.model_dump(exclude_unset=True)
    if not changes:
        raise ApiError(422, "VALIDATION_ERROR", "Provide at least one song field to update.")
    for name, value in changes.items():
        setattr(song, name, value)
    song.updated_at = _utcnow()
    db.commit()
    db.refresh(song)
    return _song_response(song)


@router.post(
    "/songs/{song_id}/assets/upload-intent",
    response_model=UploadIntentResponse,
    status_code=status.HTTP_201_CREATED,
)
def create_upload_intent(
    song_id: str,
    payload: UploadIntentRequest,
    request: Request,
    db: Session = Depends(get_db),
    owner_id: str = Depends(current_owner),
) -> UploadIntentResponse:
    _get_song(db, song_id, owner_id)
    if payload.size_bytes > settings.max_upload_bytes:
        raise ApiError(413, "AUDIO_FILE_TOO_LARGE", "The audio file exceeds the configured size limit.")
    content_type = payload.declared_content_type
    if content_type and not (content_type.startswith("audio/") or content_type == "application/octet-stream"):
        raise ApiError(415, "AUDIO_FORMAT_UNSUPPORTED", "Upload an audio file.")
    filename = PurePosixPath(payload.filename.replace("\\", "/")).name
    if not filename or filename in {".", ".."}:
        raise ApiError(422, "VALIDATION_ERROR", "A valid filename is required.")
    asset = MediaAsset(
        song_id=song_id,
        owner_id=owner_id,
        filename=filename,
        declared_content_type=content_type,
        storage_key=new_id(),
        expected_size_bytes=payload.size_bytes,
    )
    db.add(asset)
    db.commit()
    db.refresh(asset)
    upload_url = str(request.url_for("upload_asset", asset_id=asset.id))
    return UploadIntentResponse(
        asset_id=asset.id,
        upload_method="PUT",
        upload_url=upload_url,
        required_headers={"Authorization": "Bearer <token>"},
        expires_at=_utc(asset.expires_at),
    )


@router.put("/assets/{asset_id}/upload", name="upload_asset")
async def upload_asset(
    asset_id: str,
    request: Request,
    db: Session = Depends(get_db),
    owner_id: str = Depends(current_owner),
) -> Response:
    asset = db.query(MediaAsset).filter(
        MediaAsset.id == asset_id,
        MediaAsset.owner_id == owner_id,
    ).first()
    if asset is None:
        raise ApiError(404, "RESOURCE_NOT_FOUND", "Asset was not found.")
    if asset.status != "pending_upload" or _utc(asset.expires_at) < _utcnow():
        raise ApiError(409, "ASSET_NOT_READY", "The upload intent has expired or is no longer available.")
    content_length = request.headers.get("content-length")
    if content_length:
        try:
            if int(content_length) > settings.max_upload_bytes:
                raise ApiError(413, "AUDIO_FILE_TOO_LARGE", "The audio file exceeds the configured size limit.")
        except ValueError as exc:
            raise ApiError(400, "VALIDATION_ERROR", "Invalid content length.") from exc
    claimed = db.query(MediaAsset).filter(
        MediaAsset.id == asset.id,
        MediaAsset.owner_id == owner_id,
        MediaAsset.status == "pending_upload",
    ).update({"status": "uploading"}, synchronize_session=False)
    if claimed != 1:
        db.rollback()
        raise ApiError(409, "ASSET_NOT_READY", "This upload intent is already being used.")
    db.commit()
    try:
        size_bytes, checksum = await write_upload(request, asset.storage_key, asset.expected_size_bytes)
    except Exception:
        db.rollback()
        asset = db.query(MediaAsset).filter(
            MediaAsset.id == asset_id,
            MediaAsset.owner_id == owner_id,
            MediaAsset.status == "uploading",
        ).first()
        if asset is not None:
            asset.status = "pending_upload"
            db.commit()
        raise
    asset = db.query(MediaAsset).filter(
        MediaAsset.id == asset_id,
        MediaAsset.owner_id == owner_id,
    ).first()
    if asset is None:
        raise ApiError(404, "RESOURCE_NOT_FOUND", "Asset was not found.")
    asset.size_bytes = size_bytes
    asset.checksum_sha256 = checksum
    asset.status = "uploaded"
    db.commit()
    return Response(status_code=status.HTTP_204_NO_CONTENT)


@router.post(
    "/songs/{song_id}/assets/complete",
    response_model=AssetCompleteResponse,
    status_code=status.HTTP_202_ACCEPTED,
)
def complete_upload(
    song_id: str,
    payload: AssetCompleteRequest,
    background: BackgroundTasks,
    db: Session = Depends(get_db),
    owner_id: str = Depends(current_owner),
) -> AssetCompleteResponse:
    _get_song(db, song_id, owner_id)
    asset = db.query(MediaAsset).filter(
        MediaAsset.id == payload.asset_id,
        MediaAsset.song_id == song_id,
        MediaAsset.owner_id == owner_id,
    ).first()
    if asset is None:
        raise ApiError(404, "RESOURCE_NOT_FOUND", "Asset was not found.")
    if asset.status in {"verifying", "ready"}:
        existing_job = db.query(AnalysisJob).filter(
            AnalysisJob.task_type == "asset_verification",
            AnalysisJob.subject_id == asset.id,
            AnalysisJob.owner_id == owner_id,
        ).order_by(AnalysisJob.created_at.desc()).first()
        if existing_job is not None:
            return AssetCompleteResponse(
                asset_id=asset.id,
                status=asset.status,
                job_id=existing_job.id,
                status_url=f"/api/v1/jobs/{existing_job.id}",
            )
    if asset.status != "uploaded" or not original_path(asset.storage_key).is_file():
        raise ApiError(409, "ASSET_NOT_READY", "The uploaded asset is not available for verification.")
    job = AnalysisJob(owner_id=owner_id, task_type="asset_verification", subject_id=asset.id)
    db.add(job)
    asset.status = "verifying"
    db.commit()
    db.refresh(job)
    background.add_task(run_v1_job, job.id)
    return AssetCompleteResponse(
        asset_id=asset.id,
        status="verifying",
        job_id=job.id,
        status_url=f"/api/v1/jobs/{job.id}",
    )


@router.get("/songs/{song_id}/assets", response_model=AssetListOut)
def list_assets(
    song_id: str,
    db: Session = Depends(get_db),
    owner_id: str = Depends(current_owner),
) -> AssetListOut:
    _get_song(db, song_id, owner_id)
    rows = db.query(MediaAsset).filter(
        MediaAsset.song_id == song_id,
        MediaAsset.owner_id == owner_id,
    ).order_by(MediaAsset.created_at.desc()).limit(100).all()
    return AssetListOut(
        items=[
            AssetOut(
                asset_id=row.id,
                asset_kind=row.asset_kind,
                status=row.status,
                size_bytes=row.size_bytes,
                checksum_sha256=row.checksum_sha256,
                created_at=_utc(row.created_at),
            )
            for row in rows
        ]
    )


@router.post(
    "/songs/{song_id}/analyses",
    response_model=AnalysisAccepted,
    status_code=status.HTTP_202_ACCEPTED,
)
def create_analysis(
    song_id: str,
    payload: AnalysisRequest,
    background: BackgroundTasks,
    db: Session = Depends(get_db),
    owner_id: str = Depends(current_owner),
    idempotency_key: str = Header(alias="Idempotency-Key", min_length=1, max_length=200),
) -> AnalysisAccepted:
    _get_song(db, song_id, owner_id)
    if payload.lyrics_asset_id is not None:
        raise ApiError(422, "VALIDATION_ERROR", "Lyrics assets are not implemented in this milestone.")
    if payload.include_pretrained_predictions:
        raise ApiError(422, "VALIDATION_ERROR", "No reviewed pretrained prediction model is configured.")
    asset = db.query(MediaAsset).filter(
        MediaAsset.id == payload.asset_id,
        MediaAsset.song_id == song_id,
        MediaAsset.owner_id == owner_id,
    ).first()
    if asset is None:
        raise ApiError(404, "RESOURCE_NOT_FOUND", "Asset was not found.")
    if asset.status != "ready":
        raise ApiError(409, "ASSET_NOT_READY", "The audio asset must be verified before analysis.")

    operation = f"song-analysis:{song_id}"
    request_hash = hashlib.sha256(
        json.dumps(payload.model_dump(), sort_keys=True, separators=(",", ":")).encode()
    ).hexdigest()
    prior = db.query(IdempotencyRecord).filter(
        IdempotencyRecord.owner_id == owner_id,
        IdempotencyRecord.operation == operation,
        IdempotencyRecord.key == idempotency_key,
    ).first()
    if prior:
        if prior.request_hash != request_hash:
            raise ApiError(409, "IDEMPOTENCY_CONFLICT", "This idempotency key was used with a different request.")
        response_data = dict(prior.response_json)
        response_data["requested_at"] = datetime.fromisoformat(response_data["requested_at"])
        return AnalysisAccepted.model_validate(response_data)

    running = db.query(SongAnalysis).filter(
        SongAnalysis.song_id == song_id,
        SongAnalysis.asset_id == asset.id,
        SongAnalysis.owner_id == owner_id,
        SongAnalysis.status.in_(["queued", "running"]),
    ).first()
    if running:
        raise ApiError(409, "ANALYSIS_ALREADY_RUNNING", "An analysis is already running for this asset.")

    job = AnalysisJob(owner_id=owner_id, task_type="song_analysis")
    db.add(job)
    db.flush()
    analysis = SongAnalysis(
        song_id=song_id,
        asset_id=asset.id,
        owner_id=owner_id,
        job_id=job.id,
        analysis_version=payload.analysis_profile,
    )
    db.add(analysis)
    db.flush()
    job.subject_id = analysis.id
    accepted = AnalysisAccepted(
        analysis_id=analysis.id,
        job_id=job.id,
        status="queued",
        status_url=f"/api/v1/analyses/{analysis.id}",
        requested_at=_utc(analysis.created_at),
    )
    db.add(
        IdempotencyRecord(
            owner_id=owner_id,
            operation=operation,
            key=idempotency_key,
            request_hash=request_hash,
            response_json=accepted.model_dump(mode="json"),
        )
    )
    db.commit()
    background.add_task(run_v1_job, job.id, payload.generate_ai_report)
    return accepted


@router.get("/analyses/{analysis_id}", response_model=AnalysisStatusOut)
def get_analysis(
    analysis_id: str,
    db: Session = Depends(get_db),
    owner_id: str = Depends(current_owner),
) -> AnalysisStatusOut:
    analysis = _get_analysis(db, analysis_id, owner_id)
    return AnalysisStatusOut(
        analysis_id=analysis.id,
        song_id=analysis.song_id,
        status=analysis.status,
        stage=analysis.stage,
        progress_percent=analysis.progress_percent,
        created_at=_utc(analysis.created_at),
        updated_at=_utc(analysis.updated_at),
        error=_error(analysis.error_code, None),
    )


@router.get("/analyses/{analysis_id}/intelligence", response_model=SongIntelligenceOut)
def get_intelligence(
    analysis_id: str,
    db: Session = Depends(get_db),
    owner_id: str = Depends(current_owner),
) -> SongIntelligenceOut:
    analysis = _get_analysis(db, analysis_id, owner_id)
    if analysis.intelligence_json is None:
        raise ApiError(409, "ANALYSIS_NOT_COMPLETE", "Song Intelligence is not available yet.")
    return SongIntelligenceOut(
        analysis_id=analysis.id,
        song_id=analysis.song_id,
        schema_version=analysis.schema_version,
        analysis_version=analysis.analysis_version,
        created_at=_utc(analysis.updated_at),
        **analysis.intelligence_json,
    )


@router.get("/analyses/{analysis_id}/report", response_model=ARReportOut)
def get_report(
    analysis_id: str,
    db: Session = Depends(get_db),
    owner_id: str = Depends(current_owner),
) -> ARReportOut:
    analysis = _get_analysis(db, analysis_id, owner_id)
    report = db.query(AnalysisReport).filter(AnalysisReport.analysis_id == analysis.id).first()
    if report is None:
        raise ApiError(404, "REPORT_NOT_AVAILABLE", "The A&R report is not available yet.")
    return ARReportOut(
        report_id=report.id,
        analysis_id=analysis.id,
        schema_version=analysis.schema_version,
        provider=report.provider,
        model=report.model,
        prompt_version=report.prompt_version,
        created_at=report.created_at,
        **report.payload,
    )


@router.get("/jobs/{job_id}", response_model=JobOut)
def get_job(
    job_id: str,
    db: Session = Depends(get_db),
    owner_id: str = Depends(current_owner),
) -> JobOut:
    job = db.query(AnalysisJob).filter(
        AnalysisJob.id == job_id,
        AnalysisJob.owner_id == owner_id,
    ).first()
    if job is None:
        raise ApiError(404, "RESOURCE_NOT_FOUND", "Job was not found.")
    return JobOut(
        job_id=job.id,
        task_type=job.task_type,
        status=job.status,
        stage=job.stage,
        attempt=job.attempt,
        created_at=_utc(job.created_at),
        updated_at=_utc(job.updated_at),
        started_at=_utc(job.started_at),
        finished_at=_utc(job.finished_at),
        error=_error(job.error_code, None),
    )
